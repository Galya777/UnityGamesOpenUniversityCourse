
 ## Screenshot of example for C# Basics + Physics Practice
 ### Pickups
 ![Doodly Pickup](https://user-images.githubusercontent.com/25185815/108393551-70ad7a00-721c-11eb-9adf-644727a2c7e6.JPG)

Problems to discuss:
 1. Common homework problems and solutions discussion
 2. How to properly check for ground? Shape overlapping.
 3. How to move a character? Change transform.position or apply force to a rigidbody? Which is better? Why? Should we use both at the same time? Why?
 4. How to make a jumping platform that doesn't shoout you up when touching it on the sides?
 5. Live Coding: Jump on the platforms from below them
 6. Break - 30 minutes
 7. More Pickups? (Rocket headstart, reverse gravity pill?) 
 8. How to implement double jumps
 9. Add spikes
 10. Respawn droping platforms after some period of time?

 