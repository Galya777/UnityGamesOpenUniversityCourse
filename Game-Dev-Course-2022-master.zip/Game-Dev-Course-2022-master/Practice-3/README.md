1. gitignore
2. Input system
3. Settings menu for remapping controls
3.1. How could you do it with the old input system?
3.2. Player prefs
4. Level generation
4.1. Fixed number of repeated regions
4.2. Completely random but still possible 
5. Save & Load Game
6. Is everyone part of a team for the final project? Does every team have an idea for the final project?