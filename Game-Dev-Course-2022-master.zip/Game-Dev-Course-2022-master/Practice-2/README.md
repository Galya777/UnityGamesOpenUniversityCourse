
 ## Screenshot of example for AI + UI + Shaders + Animation
 
 ![Doodly Pickup](https://user-images.githubusercontent.com/25185815/108393551-70ad7a00-721c-11eb-9adf-644727a2c7e6.JPG)

Problems to discuss:
0. Start recording
0.1. Who hasn't received feedback? 
1. Delegates
2. Shaders - Camera Vignette Shader
3. Open door when 3 keys collected?
4. Heart Pickup?
5. Enemy AI in Animator?
6. Pause Menu 
7. Procedural Generation - Basics 
8. Break 11:00-11:15
9. Lose & Win state 
* Lose when hearts go zero
* Win after passing through door
10. UI Animation. 
- Pulsating hearts
- Shinging keys? 
11. Level Generation
On the fly vs Whole level generated on start
